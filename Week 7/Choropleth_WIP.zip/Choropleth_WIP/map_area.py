import json

import pandas as pd
import openpyxl
import folium
from branca.element import Figure

# 3.16000, 101.71000 : Kuala Lumpur

def read_file(filename, sheetname):
    excel_file = pd.ExcelFile(filename)
    data_d = excel_file.parse(sheet_name=sheetname)

    return data_d

if __name__ == '__main__':

    file_input = 'negeri split_no filters.xlsx'
    geojson_file = "msia_district.geojson"
    counts_file = 'counts.csv'

    print('Reading files ...')
    with open(geojson_file) as gj_f:
        geojson_data = json.load(gj_f)

    map_size = Figure(width=800, height=600)
    map_my = folium.Map(location=[3.16000, 101.71000], zoom_start=11)
    map_size.add_child(map_my)
    
    itp_list_state = read_file(file_input, 0)
    count_by_city = itp_list_state['CITY'].value_counts()
    counts_data = pd.read_csv(counts_file)

    folr = folium.Choropleth(
        geo_data=geojson_data,
        data=counts_file,
        columns=['CITY', 'count'],
        nan_fill_color="purple",
        nan_fill_opacity=0.4,
        key_on="feature.properties.NAME_2",
        fill_color="YlOrRd",
    ).add_to(map_my)

    map_my.save('area_counts.html')
    """
    for feature in geojson_data['features']:
        properties = feature['properties']
        tooltip_text = f"State: {properties['NAME_1']}<br>District: {properties['NAME_2']}"
        folium.GeoJson(feature,tooltip=tooltip_text).add_to(map_my)

    map_my.save('itp_area_map.html')
    """
